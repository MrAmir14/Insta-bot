"""
Admin Panel for InstaGrab Bot
Complete admin management system
"""

import os
import psutil
import logging
from datetime import datetime
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import ContextTypes
from config import ADMIN_IDS, DB_PATH

logger = logging.getLogger(__name__)


async def admin_panel_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /admin command"""
    user = update.effective_user
    
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ شما دسترسی ادمین ندارید!")
        return
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📊 آمار", callback_data="admin_stats"),
            InlineKeyboardButton("👥 کاربران", callback_data="admin_users"),
        ],
        [
            InlineKeyboardButton("📢 ارسال همگانی", callback_data="admin_broadcast"),
            InlineKeyboardButton("🚫 مسدودسازی", callback_data="admin_block"),
        ],
        [
            InlineKeyboardButton("⚙️ تنظیمات", callback_data="admin_settings"),
            InlineKeyboardButton("📋 لاگ‌ها", callback_data="admin_logs"),
        ],
        [
            InlineKeyboardButton("🔧 وضعیت سرور", callback_data="admin_server"),
            InlineKeyboardButton("📤 بک‌آپ", callback_data="admin_backup"),
        ],
    ])
    
    await update.message.reply_text(
        "🔐 <b>پنل مدیریت</b>\n\n"
        "به پنل مدیریت ربات خوش آمدید.\n"
        "از دکمه‌های زیر استفاده کنید:",
        parse_mode='HTML',
        reply_markup=keyboard
    )


async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin statistics"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    db = context.bot_data["db"]
    stats = await db.get_stats_summary()
    
    downloads_by_type = "\n".join([
        f"  • {k}: {v:,}" for k, v in stats.get('downloads_by_type', {}).items()
    ]) or "  هنوز دانلودی ثبت نشده"
    
    text = f"""
📊 <b>آمار کلی ربات</b>

👥 <b>کاربران:</b>
  • کل: {stats['total_users']:,}
  • فعال امروز: {stats['active_today']:,}
  • فعال هفته: {stats['active_week']:,}
  • فعال ماه: {stats['active_month']:,}
  • مسدود شده: {stats['blocked_users']:,}

📥 <b>دانلودها:</b>
  • کل: {stats['total_downloads']:,}
  
📂 <b>بر اساس نوع:</b>
{downloads_by_type}

🕐 آخرین بروزرسانی: {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 بروزرسانی", callback_data="admin_refresh_stats")]
    ])
    
    await update.message.reply_text(
        text, parse_mode='HTML', reply_markup=keyboard
    )


async def manage_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage users panel"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔍 جستجوی کاربر", callback_data="admin_search_user"),
            InlineKeyboardButton("📋 لیست کاربران", callback_data="admin_list_users"),
        ],
        [
            InlineKeyboardButton("🚫 کاربران بلاک‌شده", callback_data="admin_blocked_list"),
            InlineKeyboardButton("📊 فعال‌ترین کاربران", callback_data="admin_top_users"),
        ],
    ])
    
    await update.message.reply_text(
        "👥 <b>مدیریت کاربران</b>\n\n"
        "یک گزینه را انتخاب کنید:",
        parse_mode='HTML',
        reply_markup=keyboard
    )


async def broadcast_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start broadcast process"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📝 ارسال متن", callback_data="admin_broadcast_text"),
            InlineKeyboardButton("🖼 ارسال عکس", callback_data="admin_broadcast_photo"),
        ],
        [
            InlineKeyboardButton("📎 فوروارد پیام", callback_data="admin_broadcast_forward"),
        ],
        [
            InlineKeyboardButton("❌ انصراف", callback_data="admin_cancel"),
        ],
    ])
    
    await update.message.reply_text(
        "📢 <b>ارسال همگانی</b>\n\n"
        "نوع پیام را انتخاب کنید:",
        parse_mode='HTML',
        reply_markup=keyboard
    )


async def block_management(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Block management panel"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🚫 بلاک کاربر", callback_data="admin_block_user"),
            InlineKeyboardButton("✅ آنبلاک کاربر", callback_data="admin_unblock_user"),
        ],
        [
            InlineKeyboardButton("📋 لیست بلاک‌شده‌ها", callback_data="admin_blocked_list"),
        ],
    ])
    
    await update.message.reply_text(
        "🚫 <b>مدیریت مسدودسازی</b>\n\n"
        "یک گزینه را انتخاب کنید:",
        parse_mode='HTML',
        reply_markup=keyboard
    )


async def admin_settings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin settings panel"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔄 فعال/غیرفعال ربات", callback_data="admin_toggle_bot"),
            InlineKeyboardButton("⏱ Rate Limit", callback_data="admin_rate_limit"),
        ],
        [
            InlineKeyboardButton("📝 پیام خوش‌آمدگویی", callback_data="admin_welcome_msg"),
            InlineKeyboardButton("🔗 عضویت اجباری", callback_data="admin_force_join"),
        ],
        [
            InlineKeyboardButton("🙆 مدیریت ادمین‌ها", callback_data="admin_manage_admins"),
        ],
    ])
    
    await update.message.reply_text(
        "⚙️ <b>تنظیمات ربات</b>\n\n"
        "یک گزینه را انتخاب کنید:",
        parse_mode='HTML',
        reply_markup=keyboard
    )


async def show_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show recent logs"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    db = context.bot_data["db"]
    
    # Get last 20 downloads
    import aiosqlite
    async with aiosqlite.connect(DB_PATH) as conn:
        async with conn.execute("""
            SELECT d.user_id, d.url, d.content_type, d.download_date, u.username
            FROM downloads d 
            LEFT JOIN users u ON d.user_id = u.user_id
            ORDER BY d.download_date DESC LIMIT 20
        """) as cursor:
            rows = await cursor.fetchall()
    
    if not rows:
        await update.message.reply_text("📋 هنوز لاگی ثبت نشده.")
        return
    
    text = "📋 <b>آخرین ۲۰ دانلود:</b>\n\n"
    for row in rows:
        user_id, url, ctype, date, username = row
        username_str = f"@{username}" if username else str(user_id)
        text += f"• {username_str} | {ctype} | {date[:16]}\n"
    
    await update.message.reply_text(text, parse_mode='HTML')


async def server_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show server status"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    # Get system info
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    # Bot uptime
    uptime = datetime.now() - context.bot_data.get(
        'start_time', datetime.now()
    )
    
    text = f"""
🔧 <b>وضعیت سرور</b>

💻 <b>CPU:</b> {cpu_percent}%
{'🟢' if cpu_percent < 50 else '🟡' if cpu_percent < 80 else '🔴'}

🧠 <b>RAM:</b>
  • استفاده: {memory.percent}%
  • کل: {memory.total // (1024**3)} GB
  • آزاد: {memory.available // (1024**3)} GB

💾 <b>دیسک:</b>
  • استفاده: {disk.percent}%
  • کل: {disk.total // (1024**3)} GB
  • آزاد: {disk.free // (1024**3)} GB

⏱ <b>آپتایم ربات:</b> {str(uptime).split('.')[0]}

🕐 زمان سرور: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔄 بروزرسانی", callback_data="admin_refresh_server"),
            InlineKeyboardButton("🔁 ری‌استارت", callback_data="admin_restart_bot"),
        ],
    ])
    
    await update.message.reply_text(
        text, parse_mode='HTML', reply_markup=keyboard
    )


async def backup_database(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send database backup"""
    if update.effective_user.id not in ADMIN_IDS:
        return
    
    if os.path.exists(DB_PATH):
        await update.message.reply_document(
            document=open(DB_PATH, 'rb'),
            filename=f"backup_{datetime.now().strftime('%Y%m%d_%H%M')}.db",
            caption="📤 بک‌آپ دیتابیس\n"
                    f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
    else:
        await update.message.reply_text("❌ فایل دیتابیس یافت نشد!")


async def admin_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin inline button callbacks"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("⛔ دسترسی ندارید!", show_alert=True)
        return
    
    data = query.data
    db = context.bot_data["db"]
    
    if data == "admin_refresh_stats":
        stats = await db.get_stats_summary()
        downloads_by_type = "\n".join([
            f"  • {k}: {v:,}" 
            for k, v in stats.get('downloads_by_type', {}).items()
        ]) or "  هنوز دانلودی ثبت نشده"
        
        text = f"""
📊 <b>آمار کلی ربات</b> (بروزرسانی شد ✅)

👥 کاربران: {stats['total_users']:,}
  فعال امروز: {stats['active_today']:,}
  فعال هفته: {stats['active_week']:,}
  
📥 کل دانلودها: {stats['total_downloads']:,}

📂 بر اساس نوع:
{downloads_by_type}

🕐 {datetime.now().strftime('%H:%M:%S')}
"""
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 بروزرسانی", callback_data="admin_refresh_stats")]
        ])
        
        await query.edit_message_text(
            text, parse_mode='HTML', reply_markup=keyboard
        )
    
    elif data == "admin_refresh_server":
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        text = f"""
🔧 <b>وضعیت سرور</b> (بروزرسانی ✅)

💻 CPU: {cpu_percent}%
🧠 RAM: {memory.percent}%
💾 دیسک: {disk.percent}%

🕐 {datetime.now().strftime('%H:%M:%S')}
"""
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔄 بروزرسانی", callback_data="admin_refresh_server"),
                InlineKeyboardButton("🔁 ری‌استارت", callback_data="admin_restart_bot"),
            ],
        ])
        
        await query.edit_message_text(
            text, parse_mode='HTML', reply_markup=keyboard
        )
    
    elif data == "admin_block_user":
        await query.edit_message_text(
            "🚫 آیدی عددی کاربر را ارسال کنید:\n"
            "مثال: /block 123456789 دلیل بلاک",
            parse_mode='HTML'
        )
    
    elif data == "admin_cancel":
        await query.edit_message_text("❌ عملیات لغو شد.")
    
    elif data == "admin_broadcast_text":
        context.user_data['waiting_for'] = 'broadcast_text'
        await query.edit_message_text(
            "📝 متن پیام همگانی را ارسال کنید:\n\n"
            "⚠️ برای لغو /cancel بزنید"
        )
    
    elif data == "admin_search_user":
        context.user_data['waiting_for'] = 'search_user'
        await query.edit_message_text(
            "🔍 آیدی عددی کاربر را ارسال کنید:"
        )
    
    elif data == "admin_stats":
        await show_admin_stats(update, context)
    
    elif data == "admin_users":
        await manage_users(update, context)
    
    elif data == "admin_broadcast":
        await broadcast_start(update, context)
    
    elif data == "admin_block":
        await block_management(update, context)
    
    elif data == "admin_settings":
        await admin_settings(update, context)
    
    elif data == "admin_logs":
        await show_logs(update, context)
    
    elif data == "admin_server":
        await server_status(update, context)
    
    elif data == "admin_backup":
        await backup_database(update, context)
