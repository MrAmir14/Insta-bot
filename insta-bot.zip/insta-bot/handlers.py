"""
Message handlers for InstaGrab Bot
"""

import os
import logging
from datetime import datetime
from telegram import (
    Update, InputMediaPhoto, InputMediaVideo,
    InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import ContextTypes
from config import (
    WELCOME_MSG, HELP_MSG, PROCESSING_MSG,
    ERROR_MSG, ADMIN_IDS, RATE_LIMIT_MSG, BLOCKED_MSG
)
from instagram import InstagramService

logger = logging.getLogger(__name__)
instagram = InstagramService()

# Rate limiting storage
user_requests = {}


def check_rate_limit(user_id: int) -> bool:
    """Check if user has exceeded rate limit"""
    from config import RATE_LIMIT, RATE_LIMIT_PERIOD
    now = datetime.now()

    if user_id not in user_requests:
        user_requests[user_id] = []

    # Remove old requests
    user_requests[user_id] = [
        t for t in user_requests[user_id]
        if (now - t).seconds < RATE_LIMIT_PERIOD
    ]

    if len(user_requests[user_id]) >= RATE_LIMIT:
        return False

    user_requests[user_id].append(now)
    return True


async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user = update.effective_user
    db = context.bot_data["db"]

    # Add user to database
    await db.add_user(user.id, user.username, user.full_name)

    await update.message.reply_text(
        WELCOME_MSG.format(name=user.first_name),
        parse_mode='HTML'
    )


async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    await update.message.reply_text(HELP_MSG)


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle keyboard button texts"""
    text = update.message.text
    user = update.effective_user
    db = context.bot_data["db"]

    if text == "📥 دانلود":
        await update.message.reply_text(
            "🔗 لینک اینستاگرام را ارسال کنید:"
        )

    elif text == "👤 پروفایل من":
        user_data = await db.get_user(user.id)
        stats = await db.get_user_stats(user.id)

        text_msg = f"""
👤 <b>پروفایل شما</b>

🆔 شناسه: <code>{user.id}</code>
👤 نام: {user.full_name or 'نامشخص'}
🔛 یوزرنیم: @{user.username or 'ندارد'}
📅 تاریخ عضویت: {user_data['join_date'] if user_data else 'نامشخص'}
📊 کل دانلودها: {stats.get('total', 0)}
"""
        await update.message.reply_text(text_msg, parse_mode='HTML')

    elif text == "📊 آمار من":
        stats = await db.get_user_stats(user.id)

        by_type = stats.get('by_type', {})
        type_text = "\n".join([
            f"  • {k}: {v}" for k, v in by_type.items()
        ]) or "  هنوز دانلودی نداشتید"

        text_msg = f"""
📊 <b>آمار دانلودهای شما</b>

📥 کل دانلودها: {stats.get('total', 0)}
📅 دانلود امروز: {stats.get('today', 0)}

📂 بر اساس نوع:
{type_text}
"""
        await update.message.reply_text(text_msg, parse_mode='HTML')

    elif text == "📖 راهنما":
        await help_handler(update, context)

    elif text == "📞 پشتیبانی":
        await update.message.reply_text(
            "📞 برای ارتباط با پشتیبانی:\n\n"
            "پیام خود را همینجا بنویسید و ادمین پاسخ خواهد داد.\n"
            "یا به آیدی زیر پیام دهید:\n"
            "@admin_username"
        )


async def download_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Instagram link downloads"""
    user = update.effective_user
    db = context.bot_data["db"]
    url = update.message.text.strip()

    # Check if blocked
    if await db.is_blocked(user.id):
        await update.message.reply_text(BLOCKED_MSG)
        return

    # Check rate limit
    if not check_rate_limit(user.id):
        await update.message.reply_text(
            RATE_LIMIT_MSG.format(seconds=60)
        )
        return

    # Parse URL
    parsed = instagram.parse_url(url)

    if parsed['type'] == 'unknown':
        await update.message.reply_text(
            "❌ لینک نامعتبر! لطفاً یک لینک معتبر اینستاگرام ارسال کنید."
        )
        return

    # Send processing message
    status_msg = await update.message.reply_text(PROCESSING_MSG)

    try:
        if parsed['type'] in ('post', 'reel'):
            await handle_post_download(update, context, parsed, status_msg)

        elif parsed['type'] == 'profile':
            await handle_profile(update, context, parsed, status_msg)

        elif parsed['type'] == 'story':
            await handle_story_download(update, context, parsed, status_msg)

        elif parsed['type'] == 'highlight':
            await handle_highlight_download(update, context, parsed, status_msg)

        # Log download
        await db.log_download(user.id, url, parsed['type'])

    except Exception as e:
        logger.error(f"Download error: {e}")
        await status_msg.edit_text(
            f"❌ خطا در دانلود:\n<code>{str(e)[:200]}</code>",
            parse_mode='HTML'
        )


async def handle_post_download(update, context, parsed, status_msg):
    """Handle post/reel download"""
    shortcode = parsed['shortcode']
    result = await instagram.download_post(shortcode)

    await status_msg.edit_text("📥 در حال ارسال...")

    if result['type'] == 'video':
        # Send thumbnail first
        if result['thumbnail'] and os.path.exists(result['thumbnail']):
            await update.message.reply_photo(
                photo=open(result['thumbnail'], 'rb'),
                caption=f"🖼 پیش‌نمایش ویدیو\n👤 {result['owner']}"
            )

        # Send video
        for media in result['media_files']:
            if os.path.exists(media['path']):
                await update.message.reply_video(
                    video=open(media['path'], 'rb'),
                    caption=f"🎬 ویدیو دانلود شد\n❤️ {result['likes']:,} لایک"
                )

        # Send caption
        if result['caption']:
            caption_text = result['caption'][:4000]
            await update.message.reply_text(
                f"📝 <b>کپشن:</b>\n\n{caption_text}",
                parse_mode='HTML'
            )

    elif result['type'] == 'carousel':
        # Send all media in carousel
        media_group = []
        for i, media in enumerate(result['media_files']):
            if os.path.exists(media['path']):
                if media['type'] == 'video':
                    media_group.append(
                        InputMediaVideo(
                            open(media['path'], 'rb'),
                            caption=f"📸 {i+1}/{len(result['media_files'])}" if i == 0 else ""
                        )
                    )
                else:
                    media_group.append(
                        InputMediaPhoto(
                            open(media['path'], 'rb'),
                            caption=f"📸 {i+1}/{len(result['media_files'])}" if i == 0 else ""
                        )
                    )

        if media_group:
            # Send in batches of 10
            for i in range(0, len(media_group), 10):
                batch = media_group[i:i+10]
                await update.message.reply_media_group(batch)

        # Send caption
        if result['caption']:
            caption_text = result['caption'][:4000]
            await update.message.reply_text(
                f"📝 <b>کپشن:</b>\n\n{caption_text}\n\n"
                f"👤 {result['owner']} | ❤️ {result['likes']:,}",
                parse_mode='HTML'
            )

    elif result['type'] == 'photo':
        # Send photo
        for media in result['media_files']:
            if os.path.exists(media['path']):
                await update.message.reply_photo(
                    photo=open(media['path'], 'rb'),
                    caption=f"📸 عکس دانلود شد\n❤️ {result['likes']:,} لایک"
                )

        # Send caption
        if result['caption']:
            caption_text = result['caption'][:4000]
            await update.message.reply_text(
                f"📝 <b>کپشن:</b>\n\n{caption_text}",
                parse_mode='HTML'
            )

    # Cleanup
    for media in result['media_files']:
        instagram.cleanup(media['path'])
    if result.get('thumbnail'):
        instagram.cleanup(result['thumbnail'])

    await status_msg.delete()


async def handle_profile(update, context, parsed, status_msg):
    """Handle profile info request"""
    username = parsed['username']
    profile = await instagram.get_profile_info(username)

    await status_msg.edit_text("👤 در حال دریافت اطلاعات پروفایل...")

    # Build profile text
    verified = " ✅" if profile['is_verified'] else ""
    private = "🔒 خصوصی" if profile['is_private'] else "🌐 عمومی"

    profile_text = f"""
👤 <b>{profile['full_name']}{verified}</b>
🔛 @{profile['username']}
{private}

📝 <b>بیو:</b>
{profile['bio'] or 'بدون بیو'}

📊 <b>آمار:</b>
📸 پست‌ها: {profile['posts_count']:,}
👥 فالوور: {profile['followers']:,}
👤 فالووینگ: {profile['following']:,}
"""

    if profile['external_url']:
        profile_text += f"\n🔗 وبسایت: {profile['external_url']}"

    # Build highlight buttons
    keyboard = []
    if profile['highlights']:
        row = []
        for hl in profile['highlights']:
            row.append(
                InlineKeyboardButton(
                    f"📌 {hl['title']}",
                    callback_data=f"hl_{hl['id']}"
                )
            )
            if len(row) == 2:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)

    reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None

    # Send profile pic + info
    if profile['profile_pic_path'] and os.path.exists(profile['profile_pic_path']):
        await update.message.reply_photo(
            photo=open(profile['profile_pic_path'], 'rb'),
            caption=profile_text,
            parse_mode='HTML',
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            profile_text,
            parse_mode='HTML',
            reply_markup=reply_markup
        )

    # Cleanup
    instagram.cleanup(profile.get('profile_pic_path', ''))
    await status_msg.delete()


async def handle_story_download(update, context, parsed, status_msg):
    """Handle story download"""
    username = parsed['username']
    story_id = parsed.get('story_id')

    await status_msg.edit_text("📱 در حال دانلود استوری...")

    stories = await instagram.download_story(username, story_id)

    if not stories:
        await status_msg.edit_text("❌ استوری‌ای یافت نشد یا اکانت خصوصی است.")
        return

    for i, story in enumerate(stories):
        if os.path.exists(story['path']):
            caption = f"📱 استوری {i+1}/{len(stories)}\n📅 {story['date']}"

            if story['type'] == 'video':
                await update.message.reply_video(
                    video=open(story['path'], 'rb'),
                    caption=caption
                )
            else:
                await update.message.reply_photo(
                    photo=open(story['path'], 'rb'),
                    caption=caption
                )

        instagram.cleanup(story['path'])

    await status_msg.delete()


async def handle_highlight_download(update, context, parsed, status_msg):
    """Handle highlight download"""
    highlight_id = parsed['highlight_id']

    await status_msg.edit_text("⭐ در حال دانلود هایلایت...")

    items = await instagram.download_highlight(highlight_id)

    if not items:
        await status_msg.edit_text("❌ هایلایتی یافت نشد.")
        return

    for i, item in enumerate(items):
        if os.path.exists(item['path']):
            caption = f"⭐ هایلایت {i+1}/{len(items)}"

            if item['type'] == 'video':
                await update.message.reply_video(
                    video=open(item['path'], 'rb'),
                    caption=caption
                )
            else:
                await update.message.reply_photo(
                    photo=open(item['path'], 'rb'),
                    caption=caption
                )

        instagram.cleanup(item['path'])

    await status_msg.delete()


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle inline button callbacks"""
    query = update.callback_query
    await query.answer()

    data = query.data

    if data.startswith("hl_"):
        # Download highlight
        highlight_id = data.replace("hl_", "")
        status_msg = await query.message.reply_text("⭐ در حال دانلود هایلایت...")

        try:
            items = await instagram.download_highlight(highlight_id)

            for i, item in enumerate(items):
                if os.path.exists(item['path']):
                    caption = f"⭐ هایلایت {i+1}/{len(items)}"

                    if item['type'] == 'video':
                        await query.message.reply_video(
                            video=open(item['path'], 'rb'),
                            caption=caption
                        )
                    else:
                        await query.message.reply_photo(
                            photo=open(item['path'], 'rb'),
                            caption=caption
                        )

                instagram.cleanup(item['path'])

            await status_msg.delete()

        except Exception as e:
            await status_msg.edit_text(f"❌ خطا: {str(e)[:200]}")


async def profile_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle profile requests"""
    pass


async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle stats requests"""
    pass


async def support_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle support requests"""
    pass
