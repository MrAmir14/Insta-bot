"""
Configuration file for InstaGrab Bot
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ===== Bot Settings =====
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "123456789").split(",")]

# ===== Instagram Settings =====
INSTA_USERNAME = os.getenv("INSTA_USERNAME", "")
INSTA_PASSWORD = os.getenv("INSTA_PASSWORD", "")

# ===== Rate Limiting =====
RATE_LIMIT = int(os.getenv("RATE_LIMIT", "10"))  # requests per period
RATE_LIMIT_PERIOD = int(os.getenv("RATE_LIMIT_PERIOD", "60"))  # seconds

# ===== Database =====
DB_PATH = os.getenv("DB_PATH", "bot_database.db")

# ===== Force Join Channel =====
FORCE_JOIN_CHANNEL = os.getenv("FORCE_JOIN_CHANNEL", "")  # @channel_username

# ===== Log Channel =====
LOG_CHANNEL = os.getenv("LOG_CHANNEL", "")  # Channel ID for logging

# ===== Download Settings =====
DOWNLOAD_DIR = "downloads"
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB (Telegram limit)

# ===== Messages =====
WELCOME_MSG = """
🎉 سلام {name} عزیز!

به ربات دانلودر اینستاگرام خوش آمدید! 📥

🔹 لینک پست، ریلز، ویدیو بفرستید → دانلود کنید
🔹 لینک پروفایل بفرستید → اطلاعات کامل
🔹 استوری و هایلایت هم پشتیبانی می‌شود

⬇️ کافیه لینک اینستاگرام رو بفرستید!
"""

HELP_MSG = """
📖 راهنمای استفاده از ربات:

1️⃣ لینک پست → دانلود عکس/ویدیو + کپشن
2️⃣ لینک ریلز → کاور + ویدیو + کپشن  
3️⃣ لینک پروفایل → اطلاعات + هایلایت‌ها
4️⃣ لینک استوری → دانلود استوری

📌 فقط کافیه لینک رو کپی و ارسال کنید!

❓ مشکلی دارید؟ → دکمه پشتیبانی
"""

PROCESSING_MSG = "⏳ در حال پردازش... لطفاً صبر کنید."
ERROR_MSG = "❌ خطایی رخ داد. لطفاً دوباره تلاش کنید."
RATE_LIMIT_MSG = "⚠️ تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً {seconds} ثانیه صبر کنید."
BLOCKED_MSG = "🚫 دسترسی شما به ربات مسدود شده است."
