"""
Database module for InstaGrab Bot
Using aiosqlite for async SQLite operations
"""

import aiosqlite
import asyncio
from datetime import datetime, timedelta
from config import DB_PATH


class Database:
    def __init__(self):
        self.db_path = DB_PATH
    
    async def init(self):
        """Initialize database tables"""
        async with aiosqlite.connect(self.db_path) as db:
            # Users table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    is_blocked INTEGER DEFAULT 0,
                    block_reason TEXT,
                    total_downloads INTEGER DEFAULT 0,
                    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Downloads log table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS downloads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    url TEXT,
                    content_type TEXT,
                    download_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    status TEXT DEFAULT 'success',
                    FOREIGN KEY (user_id) REFERENCES users(user_id)
                )
            """)
            
            # Settings table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            
            # Blocked users table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS blocked_users (
                    user_id INTEGER PRIMARY KEY,
                    reason TEXT,
                    blocked_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    blocked_by INTEGER
                )
            """)
            
            await db.commit()
    
    async def add_user(self, user_id, username=None, full_name=None):
        """Add new user or update existing"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO users (user_id, username, full_name)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    username = ?,
                    full_name = ?,
                    last_active = CURRENT_TIMESTAMP
            """, (user_id, username, full_name, username, full_name))
            await db.commit()
    
    async def get_user(self, user_id):
        """Get user by ID"""
        async with aiosqlite.connect(self.db_path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                return await cursor.fetchone()
    
    async def is_blocked(self, user_id):
        """Check if user is blocked"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT is_blocked FROM users WHERE user_id = ?",
                (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                return row and row[0] == 1
    
    async def block_user(self, user_id, reason="", blocked_by=0):
        """Block a user"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE users SET is_blocked = 1, block_reason = ? WHERE user_id = ?",
                (reason, user_id)
            )
            await db.execute("""
                INSERT OR REPLACE INTO blocked_users 
                (user_id, reason, blocked_by) VALUES (?, ?, ?)
            """, (user_id, reason, blocked_by))
            await db.commit()
    
    async def unblock_user(self, user_id):
        """Unblock a user"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE users SET is_blocked = 0, block_reason = NULL WHERE user_id = ?",
                (user_id,)
            )
            await db.execute(
                "DELETE FROM blocked_users WHERE user_id = ?",
                (user_id,)
            )
            await db.commit()
    
    async def log_download(self, user_id, url, content_type, status="success"):
        """Log a download"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO downloads (user_id, url, content_type, status)
                VALUES (?, ?, ?, ?)
            """, (user_id, url, content_type, status))
            await db.execute("""
                UPDATE users SET total_downloads = total_downloads + 1
                WHERE user_id = ?
            """, (user_id,))
            await db.commit()
    
    async def get_total_users(self):
        """Get total user count"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM users") as cursor:
                row = await cursor.fetchone()
                return row[0]
    
    async def get_active_users(self, days=1):
        """Get active users in last N days"""
        async with aiosqlite.connect(self.db_path) as db:
            date_threshold = datetime.now() - timedelta(days=days)
            async with db.execute(
                "SELECT COUNT(*) FROM users WHERE last_active > ?",
                (date_threshold,)
            ) as cursor:
                row = await cursor.fetchone()
                return row[0]
    
    async def get_total_downloads(self):
        """Get total downloads count"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM downloads") as cursor:
                row = await cursor.fetchone()
                return row[0]
    
    async def get_user_stats(self, user_id):
        """Get user download stats"""
        async with aiosqlite.connect(self.db_path) as db:
            stats = {}
            
            # Total downloads
            async with db.execute(
                "SELECT COUNT(*) FROM downloads WHERE user_id = ?",
                (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                stats['total'] = row[0]
            
            # Today downloads
            today = datetime.now().strftime('%Y-%m-%d')
            async with db.execute(
                "SELECT COUNT(*) FROM downloads WHERE user_id = ? AND DATE(download_date) = ?",
                (user_id, today)
            ) as cursor:
                row = await cursor.fetchone()
                stats['today'] = row[0]
            
            # By type
            async with db.execute("""
                SELECT content_type, COUNT(*) FROM downloads 
                WHERE user_id = ? GROUP BY content_type
            """, (user_id,)) as cursor:
                rows = await cursor.fetchall()
                stats['by_type'] = {row[0]: row[1] for row in rows}
            
            return stats
    
    async def get_all_user_ids(self):
        """Get all user IDs for broadcast"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT user_id FROM users WHERE is_blocked = 0"
            ) as cursor:
                rows = await cursor.fetchall()
                return [row[0] for row in rows]
    
    async def get_stats_summary(self):
        """Get complete stats summary for admin"""
        stats = {
            'total_users': await self.get_total_users(),
            'active_today': await self.get_active_users(1),
            'active_week': await self.get_active_users(7),
            'active_month': await self.get_active_users(30),
            'total_downloads': await self.get_total_downloads(),
        }
        
        async with aiosqlite.connect(self.db_path) as db:
            # Downloads by type
            async with db.execute("""
                SELECT content_type, COUNT(*) FROM downloads 
                GROUP BY content_type ORDER BY COUNT(*) DESC
            """) as cursor:
                rows = await cursor.fetchall()
                stats['downloads_by_type'] = {
                    row[0]: row[1] for row in rows
                }
            
            # Blocked users count
            async with db.execute(
                "SELECT COUNT(*) FROM users WHERE is_blocked = 1"
            ) as cursor:
                row = await cursor.fetchone()
                stats['blocked_users'] = row[0]
        
        return stats
