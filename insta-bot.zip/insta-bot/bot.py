#!/usr/bin/env python3
"""
InstaGrab Bot - Instagram Downloader Telegram Bot
Main entry point
"""

import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters
)
from config import BOT_TOKEN, ADMIN_IDS
from database import Database
from handlers import (
    start_handler, help_handler, download_handler,
    profile_handler, stats_handler, support_handler,
    button_handler, text_handler
)
from admin import admin_panel_handler, admin_callback_handler

# Setup logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Initialize database
db = Database()


async def post_init(application):
    """Initialize database on startup"""
    await db.init()
    logger.info("✅ Database initialized")
    logger.info("✅ Bot started successfully!")
    
    # Notify admins
    for admin_id in ADMIN_IDS:
        try:
            await application.bot.send_message(
                admin_id,
                "✅ ربات با موفقیت راه‌اندازی شد!\n"
                "📊 از پنل ادمین استفاده کنید."
            )
        except Exception:
            pass


def main():
    """Main function to run the bot"""
    
    # Build application
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    
    # Store database in bot_data
    app.bot_data["db"] = db
    
    # ===== Command Handlers =====
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(CommandHandler("help", help_handler))
    app.add_handler(CommandHandler("admin", admin_panel_handler))
    
    # ===== Callback Query Handler =====
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^admin_"))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    # ===== Message Handlers =====
    # Instagram link handler (priority)
    app.add_handler(MessageHandler(
        filters.TEXT & filters.Regex(
            r'(instagram\.com|instagr\.am)'
        ),
        download_handler
    ))
    
    # Text message handler (for keyboard buttons)
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        text_handler
    ))
    
    # Run the bot
    logger.info("🚀 Starting InstaGrab Bot...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
