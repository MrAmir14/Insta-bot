"""
Instagram Service - Download content from Instagram
Works in anonymous mode without login
"""

import os
import re
import asyncio
import logging
import httpx
import instaloader
from typing import Dict, List, Any
from config import DOWNLOAD_DIR

logger = logging.getLogger(__name__)

# Ensure download directory exists
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


class InstagramService:
    def __init__(self):
        self.loader = instaloader.Instaloader(
            download_videos=True,
            download_video_thumbnails=False,
            download_comments=False,
            save_metadata=False,
            compress_json=False,
            dirname_pattern=DOWNLOAD_DIR,
            filename_pattern="{shortcode}_{mediaid}"
        )

    def parse_url(self, url: str) -> Dict[str, str]:
        """Parse Instagram URL and determine content type"""
        url = url.strip().rstrip('/')
        url_clean = url.split('?')[0]

        patterns = {
            'post': r'instagram\.com/p/([a-zA-Z0-9_-]+)',
            'reel': r'instagram\.com/reel/([a-zA-Z0-9_-]+)',
            'reels': r'instagram\.com/reels/([a-zA-Z0-9_-]+)',
            'story': r'instagram\.com/stories/([^/]+)/([0-9]+)',
            'highlight': r'instagram\.com/stories/highlights/([0-9]+)',
            'profile': r'instagram\.com/([a-zA-Z0-9_.]+)/?$',
        }

        for content_type, pattern in patterns.items():
            match = re.search(pattern, url)
            if match:
                if content_type == 'story':
                    return {
                        'type': 'story',
                        'username': match.group(1),
                        'story_id': match.group(2)
                    }
                elif content_type in ('post', 'reel', 'reels'):
                    return {
                        'type': 'reel' if content_type == 'reels' else content_type,
                        'shortcode': match.group(1)
                    }
                elif content_type == 'highlight':
                    return {
                        'type': 'highlight',
                        'highlight_id': match.group(1)
                    }
                elif content_type == 'profile':
                    username = match.group(1)
                    if username not in ('p', 'reel', 'reels', 'stories', 'explore'):
                        return {
                            'type': 'profile',
                            'username': username
                        }

        return {'type': 'unknown'}

    async def download_post(self, shortcode: str) -> Dict[str, Any]:
        """Download a post (photo/video/carousel)"""
        result = {
            'type': None,
            'media_files': [],
            'caption': '',
            'thumbnail': None,
            'owner': 'Unknown',
            'likes': 0,
        }

        try:
            # Get post info (anonymous mode - works for public posts)
            post = instaloader.Post.from_shortcode(
                self.loader.context, shortcode
            )

            # Try to get metadata (may fail with 403 for anonymous)
            try:
                result['caption'] = post.caption or ''
                result['owner'] = post.owner_username
                result['likes'] = post.likes
            except Exception as e:
                logger.warning(f"Could not get metadata: {e}")
                result['owner'] = shortcode

            if post.typename == 'GraphSidecar':
                # Carousel post
                result['type'] = 'carousel'
                for i, node in enumerate(post.get_sidecar_nodes()):
                    file_path = os.path.join(
                        DOWNLOAD_DIR,
                        f"{shortcode}_{i}"
                    )
                    if node.is_video:
                        url = node.video_url
                        file_path += '.mp4'
                        result['media_files'].append({
                            'path': file_path,
                            'type': 'video',
                            'url': url
                        })
                    else:
                        url = node.display_url
                        file_path += '.jpg'
                        result['media_files'].append({
                            'path': file_path,
                            'type': 'photo',
                            'url': url
                        })

                    # Download file
                    await self._download_file(url, file_path)

            elif post.is_video:
                # Video/Reel post
                result['type'] = 'video'
                video_path = os.path.join(DOWNLOAD_DIR, f"{shortcode}.mp4")
                thumb_path = os.path.join(DOWNLOAD_DIR, f"{shortcode}_thumb.jpg")

                await self._download_file(post.video_url, video_path)
                await self._download_file(post.url, thumb_path)

                result['media_files'].append({
                    'path': video_path,
                    'type': 'video',
                    'url': post.video_url
                })
                result['thumbnail'] = thumb_path

            else:
                # Single photo
                result['type'] = 'photo'
                photo_path = os.path.join(DOWNLOAD_DIR, f"{shortcode}.jpg")
                await self._download_file(post.url, photo_path)

                result['media_files'].append({
                    'path': photo_path,
                    'type': 'photo',
                    'url': post.url
                })

            return result

        except Exception as e:
            logger.error(f"Error downloading post {shortcode}: {e}")
            raise

    async def get_profile_info(self, username: str) -> Dict[str, Any]:
        """Get profile information (anonymous mode - limited)"""
        try:
            profile = instaloader.Profile.from_username(
                self.loader.context, username
            )

            # Download profile pic
            pic_path = os.path.join(DOWNLOAD_DIR, f"{username}_profile.jpg")
            try:
                await self._download_file(profile.profile_pic_url, pic_path)
            except Exception:
                pic_path = None

            return {
                'username': profile.username,
                'full_name': profile.full_name,
                'bio': profile.biography,
                'followers': profile.followers,
                'following': profile.followees,
                'posts_count': profile.mediacount,
                'is_verified': profile.is_verified,
                'is_private': profile.is_private,
                'external_url': profile.external_url,
                'profile_pic_path': pic_path,
                'profile_pic_url': profile.profile_pic_url,
                'highlights': []
            }

        except Exception as e:
            logger.error(f"Error getting profile {username}: {e}")
            raise

    async def download_story(self, username: str, story_id: str = None) -> List[Dict]:
        """Download stories - requires login, so not available in anonymous mode"""
        raise Exception(
            "Stories require Instagram login. Please use a session file."
        )

    async def download_highlight(self, highlight_id: str) -> List[Dict]:
        """Download highlights - requires login, so not available in anonymous mode"""
        raise Exception(
            "Highlights require Instagram login. Please use a session file."
        )

    async def _download_file(self, url: str, path: str):
        """Download a file from URL"""
        async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()
            with open(path, 'wb') as f:
                f.write(response.content)

    def cleanup(self, *file_paths):
        """Remove downloaded files"""
        for path in file_paths:
            if path and os.path.exists(path):
                try:
                    if os.path.isdir(path):
                        import shutil
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                except Exception:
                    pass
