"""
Keyboard layouts for InstaGrab Bot
Reply Keyboards (white buttons) for main menus
Inline Keyboards (glass buttons) for sub-menus
"""

from telegram import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardButton, InlineKeyboardMarkup
)


def get_user_keyboard():
    """Get main user keyboard (white/reply buttons)"""
    keyboard = [
        [
            KeyboardButton("📥 دانلود"),
            KeyboardButton("👤 پروفایل من"),
        ],
        [
            KeyboardButton("📊 آمار من"),
            KeyboardButton("📖 راهنما"),
        ],
        [
            KeyboardButton("📞 پشتیبانی"),
        ],
    ]
    return ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True,
        one_time_keyboard=False
    )


def get_admin_keyboard():
    """Get admin keyboard (white/reply buttons)"""
    keyboard = [
        [
            KeyboardButton("📊 آمار کلی"),
            KeyboardButton("👥 مدیریت کاربران"),
        ],
        [
            KeyboardButton("📢 ارسال همگانی"),
            KeyboardButton("🚫 مسدودسازی"),
        ],
        [
            KeyboardButton("⚙️ تنظیمات"),
            KeyboardButton("📋 لاگ‌ها"),
        ],
        [
            KeyboardButton("🔧 عملکرد سرور"),
            KeyboardButton("📤 بک‌آپ"),
        ],
        [
            KeyboardButton("🔙 برگشت به پنل کاربر"),
        ],
    ]
    return ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True,
        one_time_keyboard=False
    )


def get_profile_highlights_keyboard(highlights):
    """Get inline keyboard for profile highlights"""
    keyboard = []
    row = []

    for hl in highlights:
        btn = InlineKeyboardButton(
            f"📌 {hl['title']}",
            callback_data=f"hl_{hl['id']}"
        )
        row.append(btn)

        if len(row) == 2:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    return InlineKeyboardMarkup(keyboard) if keyboard else None


def get_download_type_keyboard():
    """Inline keyboard for download type selection"""
    keyboard = [
        [
            InlineKeyboardButton("📸 عکس", callback_data="dl_photo"),
            InlineKeyboardButton("🎬 ویدیو", callback_data="dl_video"),
        ],
        [
            InlineKeyboardButton("📱 استوری", callback_data="dl_story"),
            InlineKeyboardButton("⭐ هایلایت", callback_data="dl_highlight"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


def get_confirm_keyboard():
    """Inline keyboard for confirmation"""
    keyboard = [
        [
            InlineKeyboardButton("✅ تأیید", callback_data="confirm_yes"),
            InlineKeyboardButton("❌ لغو", callback_data="confirm_no"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


def get_broadcast_confirm_keyboard(count):
    """Inline keyboard for broadcast confirmation"""
    keyboard = [
        [
            InlineKeyboardButton(
                f"✅ ارسال به {count} کاربر",
                callback_data="broadcast_confirm"
            ),
        ],
        [
            InlineKeyboardButton("❌ لغو", callback_data="admin_cancel"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)
